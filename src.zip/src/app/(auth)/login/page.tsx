"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import { GraduationCap, Mail, Lock, Loader2, Eye, EyeOff } from "lucide-react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { toast } from "sonner"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { loginSchema, LoginInput } from "@/lib/validations"

export default function LoginPage() {
  const router = useRouter()
  const [showPassword, setShowPassword] = React.useState(false)
  const [isCheckingAuth, setIsCheckingAuth] = React.useState(true)

  React.useEffect(() => {
    async function checkAuth() {
      try {
        const res = await fetch("/api/auth/me")
        const data = await res.json()
        if (data.success) {
          router.replace("/")
          return
        }
      } catch {

      }
      setIsCheckingAuth(false)
    }
    checkAuth()
  }, [router])

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  })

  const onSubmit = async (data: LoginInput) => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      const result = await res.json()

      if (!result.success) {
        toast.error(result.message)
        return
      }

      toast.success("تم تسجيل الدخول بنجاح")
      router.push(`/dashboard/${result.user.role}`)
    } catch {
      toast.error("حدث خطأ غير متوقع")
    }
  }

  if (isCheckingAuth) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="glass-card border-primary/10">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto bg-primary p-3 rounded-xl w-fit">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl">مرحباً بعودتك</CardTitle>
              <CardDescription className="mt-2">
                قم بتسجيل الدخول للوصول إلى حسابك
              </CardDescription>
            </div>
          </CardHeader>

            <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                          البريد الإلكتروني
                      </label>

                      <div className="relative">
                          <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <input
                          id="email"
                          type="email"
                          placeholder="name@example.com"
                          className={cn(
                              "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pr-10 text-sm",
                              "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pr-10 text-sm ring-offset-background",
                              "placeholder:text-muted-foreground",
                              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                              "disabled:cursor-not-allowed disabled:opacity-50",
                              errors.email && "border-destructive focus-visible:ring-destructive"
                          )}
                          {...register("email")}
                          disabled={isSubmitting}
                          dir="ltr"
                          />
                      </div>

                      {errors.email &&(
                        <p className="text-sm text-destructive">{errors.email.message}</p>
                      )}

                    {/* ⬇ error message for email, then closing tags */}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="password" className="text-sm font-medium">
                        كلمة المرور
                      </label>

                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          className={cn(
                            "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pr-10 text-sm",
                            "ring-offset-background placeholder:text-muted-foreground",
                            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                            "disabled:cursor-not-allowed disabled:opacity-50",
                            errors.password && "border-destructive focus-visible:ring-destructive"
                          )}
                          {...register("password")}
                          disabled={isSubmitting}
                          dir="ltr"
                        />

                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </button>

                        {/* ⬇ Eye / EyeOff toggle button probably goes here */}
                      </div>

                      {errors.password && (
                        <p className="text-xs text-destructive">{errors.password.message}</p>
                      )}


                      {/* ⬇ error message for password */}
                    </div>

                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                          جاري تسجيل الدخول...
                        </>
                      ) : (
                        "تسجيل الدخول"
                      )}
                    </Button>

                    <p className="text-center text-sm text-muted-foreground">
                      ليس لديك حساب؟{" "}
                      <Link
                        href="/signup"
                        className="text-primary hover:underline font-medium"
                      >
                        إنشاء حساب جديد
                      </Link>
                    </p>

                    {/* ⬇ password field, submit button */}
                </form>
            </CardContent>

        </Card>
      </motion.div>
    </div>
  )

}